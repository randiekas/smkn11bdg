<section class="hbox stretch">
  <section>
    <section class="vbox">
      <section class="scrollable padder">
        <h3 class="m-b-xs text-black">Profile | <span class="text-sm">Setup Profile.</span></h3>
		<hr>
        <div class="row">
         	<div class="col-sm-4">
                <section class="panel panel-default">
                  <div class="panel-body">
                    <div class="clearfix text-center m-t">
                      <div class="inline">

                          <div class="thumb-lg"> <img src="<?=base_url()?>/assets/dosen/default.jpg" class="imgChangeImage"> </div>

                        <div class="h4 m-t m-b-xs">
                          <form enctype="multipart/form-data" action="<?=site_url()?>/dashboard/saveImageProfile" method="POST" id="formChangeImage">
						  <input type="hidden" name="nip">
                          <input type="file" name="Image" class="changePicture hide">
                          <a href="#" class="btn btn-default btn-sm btn-rounded btn-s-sm" onclick="$('.changePicture').click()">Change</a>
                          <a href="#" onclick="$('#formChangeImage').submit()" class="btn btn-default btn-sm btn-rounded btn-s-sm btn-primary btnSubmitChangeImage" data-toggle="class:show inline" data-target="#spin" data-loading-text="Saving...">Save</a>
                          <i class="fa fa-spin fa-spinner hide" id="spin"></i>
                          </form>
                        </div>

                    </div>
                  </div>
				  </div>
                  <div class="list-group no-radius alt">  <a class="list-group-item" href="javascript:$('#ATabIdentitiyOfTheFoundation').click()"><span class="label bg-primary"><i class="fa fa-home icon-muted"></i></span> Profile</a> <a class="list-group-item" href="javascript:$('#ATabIdentityofTheColege').click()"> <span class="label bg-info"><i class="fa fa-home icon-muted"></i></span> Akun</a> </div>
            		</section>
              </div>
        	<div class="col-sm-8">
              <section class="panel panel-default">
                  <header class="panel-heading bg-light">
                    <ul class="nav nav-tabs pull-right">
                      <li class="active"><a id="ATabIdentitiyOfTheFoundation" href="#TabIdentitiyOfTheFoundation" data-toggle="tab"><span class="label bg-primary"><i class="fa fa-home icon-muted"></i></span>  Profile</a></li>
					  <li><a id="ATabIdentityofTheColege" href="#TabIdentityofTheColege" data-toggle="tab"><span class="label bg-success"><i class="fa fa-home icon-muted"></i></span>  Login</a></li>
                      

                    </ul>
                    <span class="hidden-sm">Setup Profile</span> </header>
                  <div class="panel-body">
                    <div class="tab-content">
                      <div class="tab-pane active" id="TabIdentitiyOfTheFoundation">
                         <form class="bs-example form-horizontal formIdentityofTheFoundation" action="<?=site_url()?>/dashboard/saveProfile" method="POST">
							<input type="hidden" name="id">
                          <h5>Identity Detail<hr></h5>

                          <div class="form-group">

                            <label class="col-sm-4 control-label">Sandi Dosen *</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="sandi_dosen" class="form-control" placeholder="1XXXX" required="true">
                            </div>

                          </div>
                          <div class="form-group">
                            <label class="col-sm-4 control-label">NIP *</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="nip" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">NIDN *</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="nidn" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">NIK *</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="nik" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Tempat Lahir </label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="tmplahir" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Tanggal Lahir </label>
                            <div class="col-sm-8 input-group-sm">
								<div class="tgllahir" name="tgllahir"></div>
                              
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Agama *</label>
                            <div class="col-sm-8 input-group-sm">
                              <select name="agama" class="form-control">
                          <?php
                          $this->db->select("ref_kode,ref_nama");
                         $this->db->where("ref_grup","51");
                         $agama = $this->db->get("referensi");
                         foreach($agama->result() as $row)
                         {
                          ?>
                          <option value="<?=$row->ref_kode?>"><?=$row->ref_nama?></option>
                          <?php
                          }
                          ?>
                        </select>
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Kewarganegeraan </label>
                            <div class="col-sm-8 input-group-sm">
                              <select class="form-control" name="kewarganegaraan">
                          <?php
                          $this->db->select("ref_kode,ref_nama");
                          $this->db->where("ref_grup","50");
                          $agama = $this->db->get("referensi");
                          foreach($agama->result() as $row)
                          {
                          ?>
                          <option value="<?=$row->ref_kode?>"><?=$row->ref_nama?></option>
                          <?php
                          }
                          ?>
                        </select>
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">JK *</label>
                            <div class="col-sm-3">
                        <label class="radio">
                          <input type="radio" name="jk" id="optionsRadios1" value="L">Pria
                        </label>
                      </div>
                      <div class="col-sm-3">
                        <label class="radio"  style="margin-left:-50px">
                          <input type="radio" name="jk" id="optionsRadios1" value="P">Wanita
                        </label>
                      </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Gol Darah </label>
                            <div class="col-sm-8 input-group-sm">
                              <select class="form-control" name="goldarah">
                          <option>A</option>
                          <option>B</option>
                          <option>AB</option>
                          <option>O</option>
                        </select>
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Status Sipil </label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="status_sipil" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Alamat</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="alamat_tinggal" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Provinsi</label>
                            <div class="col-sm-8 input-group-sm">
                              <select class="form-control" name="provinsi">
                          <?php
                          $this->db->select("lokasi_propinsi,lokasi_nama");
                          $this->db->where("lokasi_kabupatenkota","00");
                          foreach($this->db->get("inf_lokasi")->result() as $row)
                          {
                          ?>
                          <option value="<?=$row->lokasi_propinsi?>"><?=$row->lokasi_nama?></option>
                          <?php
                          }
                          ?>
                        </select>
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Kota</label>
                            <div class="col-sm-8 input-group-sm">
                              <select class="form-control" name="kota">

                        </select>
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Kode POS</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="kodepos" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Telepon</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="telepon" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">FAX</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="fax" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  <div class="form-group">
                            <label class="col-sm-4 control-label">Email</label>
                            <div class="col-sm-8 input-group-sm">
                              <input type="text" name="email" class="form-control" placeholder="Name ..." required="">
                            </div>
                          </div>
						  
						  
                          
     						<hr>


                          <div class="form-group text-right">
                            <div class="col-lg-offset-2 col-lg-10">							  <i class="fa fa-spin fa-spinner hide" id="spin2"></i>
                              <button type="submit" onclick="$('.formIdentityofTheFoundation').submit()" class="btn btn-sm btn-primary btn-s-xs btnSave2" data-toggle="class:show inline" data-target="#spin2" data-loading-text="Saving...">Save</button>
                              <button type="reset" class="btn btn-sm btn-default btn-s-xs">Cancel</button>
                            </div>
                          </div>
                        </form>

                  </div>
						<div class="tab-pane" id="TabIdentityofTheColege">
						<form class="bs-example form-horizontal formLogin" action="<?=site_url()?>/dashboard/admin/saveChangePassword" method="POST">
                          <h5>Login Setting<hr></h5>
							  <div class="form-group">

								<label class="col-sm-4 control-label">Password Lama *</label>
								<div class="col-sm-8 input-group-sm">
								  <input type="password" name="oldPassword" class="form-control" placeholder="1XXXX" required="true">
								</div>

							  </div>
							  <div class="form-group">

								<label class="col-sm-4 control-label">Password Baru *</label>
								<div class="col-sm-8 input-group-sm">
								  <input type="password" name="newPassword" class="form-control" placeholder="1XXXX" required="true">
								</div>

							  </div>
							  <div class="form-group">

								<label class="col-sm-4 control-label">Ulangi Password Baru *</label>
								<div class="col-sm-8 input-group-sm">
								  <input type="password" name="repeatPassword" class="form-control" placeholder="1XXXX" required="true">
								</div>

							  </div>
							  <div class="form-group text-right">
                            <div class="col-lg-offset-2 col-lg-10"><i class="fa fa-spin fa-spinner hide" id="spin2"></i>
                              <button type="submit" onclick="$('.formLogin').submit()" class="btn btn-sm btn-primary btn-s-xs">Save</button>
                              <button type="reset" class="btn btn-sm btn-default btn-s-xs">Cancel</button>
                            </div>
                          </div>
						</form>
						</div>
                    </div>
                  </div>
                </section>
            </div>
          </div>
	         <script type="text/javascript" src="<?=base_url()?>assets/backend/js/datepicker/bootstrap-datepicker.js"></script>
            <script type="text/javascript">
              //$(".datepicker-input").each(function(){ $(this).datepicker();});
              $(document).ready(function(){
				  $(".tgllahir").jqxDateTimeInput({formatString: 'yyyy-MM-dd'});
                //$(".datepicker-input").each(function(){ $(this).datepicker();});
                $.ajax({
                  url:"<?=site_url()?>/dashboard/getProfile",
                  dataType:"json",
                  type:"get",
                  success:function(result){
                    $(".formIdentityofTheFoundation input,.formIdentityofTheFoundation textarea,.formIdentityofTheFoundation select").each(function(){
						if($(this).attr("type")=="radio")
						{
						  $("input[type=radio][name='"+$(this).attr("name")+"']").removeAttr("checked");
						  $("input[type=radio][name='"+$(this).attr("name")+"'][value='"+result[$(this).attr("name")]+"']").prop("checked",true);

						}
						if($(this).attr("name")=="kota")
						{
							
						  set_kota(result[$(this).attr("name")],"provinsi","kota");
						}
						else{
								$(this).val(result[$(this).attr("name")]);
						}
                        
                      });
                    $(".formIdentityofTheCollege input,.formIdentityofTheCollege textarea").each(function(){
                          $(this).val(result[$(this).attr("name")]);
                        });
                    $(".imgChangeImage").attr("src","<?=base_url()?>assets/dosen/"+result["nip"]+".jpg");
					$("#formChangeImage [name=nip]").val(result['nip']);
                  }
                });
				$('[name="provinsi"]').change(function(){
					$.ajax({
					  type:'POST',
					  url: "<?=site_url()?>/dashboard/getKota/",
					  data:{kode_propinsi:$(this).val()},
					  success:function(result){
						$('[name="kota"]').html(result);

					  }
					});
				  });
                $("#formChangeImage").submit(function(){
                  var formData = new FormData(this);
                	$.ajax({
                		type:'POST',
                		url: $(this).attr('action'),
                		data:formData,
                    dataType:'json',
                		cache:false,
                		contentType: false,
                		processData: false,
                		success:function(result){
                        if(result.status=="success")
                        {
                          $("#spin").removeClass("show");
                          $("#spin").removeClass("inline");
                          $(".btnSubmitChangeImage").html("Save");
                          $(".btnSubmitChangeImage").removeClass("disabled");
                          $(".btnSubmitChangeImage").removeAttr("disabled");
                          //$(".imgChangeImage").attr("src",$(".imgChangeImage").attr("src"));
                          $(".imgChangeImage").attr("src","<?=base_url()?>assets/dosen/"+$("[name=nip]:first").val()+".jpg");

                          Notification.open(result.message,"success");
                        }
                        else{
                          $("#spin").removeClass("show");
                          $("#spin").removeClass("inline");
                          $(".btnSubmitChangeImage").html("Save");
                          $(".btnSubmitChangeImage").removeClass("disabled");
                          $(".btnSubmitChangeImage").removeAttr("disabled");

                          Notification.open(result.message,"error");
                        }
                    },
                    error:function(){
                        Notification.open("Connection lost, Check your Connection and try again !","error");

                    }
                    });
                    return false;
                });
                $(".formIdentityofTheFoundation").submit(function(){
                  var formData = new FormData(this);
                	$.ajax({
                		type:'POST',
                		url: $(this).attr('action'),
                		data:formData,
                    dataType:'json',
                		cache:false,
                		contentType: false,
                		processData: false,
                		success:function(result){
                        if(result.status=="success")
                        {
                          $("#spin2").removeClass("show");
                          $("#spin2").removeClass("inline");
                          $(".btnSave2").html("Save");
                          $(".btnSave2").removeClass("disabled");
                          $(".btnSave2").removeAttr("disabled");

                          Notification.open(result.message,"success");
                        }
                        else{
                          $("#spin2").removeClass("show");
                          $("#spin2").removeClass("inline");
                          $(".btnSave2").html("Save");
                          $(".btnSave2").removeClass("disabled");
                          $(".btnSave2").removeAttr("disabled");

                          Notification.open(result.message,"error");
                        }
                    },
                    error:function(){
                        Notification.open("Connection lost, Check your Connection and try again !","error");
                    }
                    });
                    return false;
                });
                $(".formLogin").submit(function(){
					var oldPassword = $("[name=oldPassword]").val();
					var newPassword = $("[name=newPassword]").val();
					var repeatPassword = $("[name=repeatPassword]").val();
					if(oldPassword!="<?=$this->session->userdata("password")?>")
					{
						alert.alert("Akun","Password Lama Salah",function(){});
						return false;
					}
					if(newPassword!=repeatPassword)
					{
						alert.alert("Akun","Password Baru tidak cocok",function(){});
						return false;
					}
                  var formData = new FormData(this);
                	$.ajax({
                		type:'POST',
                		url: $(this).attr('action'),
                		data:formData,
                    dataType:'json',
                		cache:false,
                		contentType: false,
                		processData: false,
                		success:function(result){
                        if(result.status=="success")
                        {
                          $("#spin3").removeClass("show");
                          $("#spin3").removeClass("inline");
                          $(".btnSave3").html("Save");
                          $(".btnSave3").removeClass("disabled");
                          $(".btnSave3").removeAttr("disabled");

                          Notification.open(result.message,"success");
                        }
                        else{
                          $("#spin3").removeClass("show");
                          $("#spin3").removeClass("inline");
                          $(".btnSave3").html("Save");
                          $(".btnSave3").removeClass("disabled");
                          $(".btnSave3").removeAttr("disabled");

                          Notification.open(result.message,"error");
                        }
                    },
                    error:function(){
                        Notification.open("Connection lost, Check your Connection and try again !","error");
                    }
                    });
                    return false;
                });
				
					
              });
			  function set_kota(kode_kota,name_provinsi,name_kota)
			  {
				//console.log(kode_kota);
				$.ajax({
				  type:'POST',
				  url: "<?=site_url()?>/dashboard/getKota/",
				  data:{kode_propinsi:$('[name="'+name_provinsi+'"]').val(),kode_kota:kode_kota},
				  success:function(result){
					$('[name="'+name_kota+'"]').html(result);

				  }
				});
			  }
            </script>
    </section>
    </section>
  </section>
</section>
